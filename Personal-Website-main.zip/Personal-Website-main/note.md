1. Create new project Vite

```
pnpm create vite@latest .
or 
pnpm create vite@latest project-name
```

