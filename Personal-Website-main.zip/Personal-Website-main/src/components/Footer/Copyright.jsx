export default function Copyright() {

    return (
        <>
            <p className="text-center">&copy; 2023-2024 <a className="font-semibold text-red-500 dark:text-sky-500 hover:opacity-[.85]" href="/">hamdanzull</a> - All Rights Reserved.</p>
        </>
    )
}